package com.example.teste2.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Olá, eu sou Robson Lins! :D \n\n\n *Estudante de CC da UNICAP \n *Estagiário de Robótica"
    }
    val text: LiveData<String> = _text
}